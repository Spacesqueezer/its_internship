# Легаси в других проектах чтобы не сломалось
from integration_utils.iu_datetime.dt_its import dt_its, DtIts
from settings import ilogger

ilogger.warning('deprecated', 'its_utils.app_datetime.dt_its is deprecated. Use integration_utils.iu_datetime.dt_its instead.')