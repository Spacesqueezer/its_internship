from django.apps import AppConfig

class Config(AppConfig):
    name = 'integration_utils.bitrix24'
    #verbose_name = "bitrix_telegram_log для порталов"
    default_auto_field = "django.db.models.AutoField"