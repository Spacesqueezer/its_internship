# Скоируйте этот файл в папку с джанго приложением и переименуйте в admin.py
from integration_utils.its_utils.app_admin.auto_register import auto_register

auto_register("Замените на имя прлиложения")