from .install import install
from .uninstall import uninstall
