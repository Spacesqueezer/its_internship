from integration_utils.itsolution.functions.auto_register import auto_register

auto_register('example_robot')
